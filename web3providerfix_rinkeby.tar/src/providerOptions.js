export const providerUrl="https://rinkeby.infura.io/v3/5a4e19427c10436fbbbf6b6526e37ba0";
export const wsUrl = "wss://rinkeby.infura.io/ws"
//export const providerUrl="http://localhost:9545";
//export const wsUrl = "ws://localhost:9545";

